import pygame
import sys
import math
import os
import asyncio

# ==========================================
# CONFIGURATION & DATA
# ==========================================
WIDTH, HEIGHT = 1280, 720
FPS = 60

# Unique colors for each course box on the report screen
COURSE_COLORS = {
    "DMD": (243, 139, 168),     # Pink
    "GAMES": (166, 227, 161),   # Green
    "MODANIM": (250, 179, 135), # Peach
    "CODING": (137, 180, 250),  # Blue
    "AIML": (203, 166, 247),    # Mauve
    "ARCHVIZ": (249, 226, 175)  # Yellow
}

# Modern Color Palette
COLORS = {
    "bg": (30, 30, 46),            # Deep space blue/grey
    "primary": (137, 180, 250),    # Soft blue
    "secondary": (203, 166, 247),  # Soft purple
    "text_light": (205, 214, 244), # Off-white text
    "text_dark": (17, 17, 27),     # Dark text for buttons
    "btn_bg": (49, 50, 68),        # Button background
    "btn_hover": (69, 71, 90),     # Button hover
    "card": (24, 24, 37)           # Report card background
}

# Course Dictionary
COURSES = {
    "DMD": "Digital Media Design",
    "GAMES": "3D Games Design",
    "MODANIM": "3D Modelling & Animation",
    "CODING": "Python Coding",
    "AIML": "AI & Machine Learning",
    "ARCHVIZ": "Architectural Visualisation"
}

# Quiz Questions & Point Logic
QUESTIONS = [
    {
        "question": "My favourite subject is...",
        "options": [
            {"text": "Art", "points": ["DMD", "MODANIM", "GAMES"]},
            {"text": "Maths", "points": ["CODING", "AIML", "ARCHVIZ"]},
            {"text": "Science", "points": ["CODING", "MODANIM", "GAMES"]},
            {"text": "Computing", "points": ["CODING", "AIML", "GAMES"]}
        ]
    },
    {
        "question": "In my free time, I like to...",
        "options": [
            {"text": "Draw, write, and create worlds", "points": ["DMD", "MODANIM"]},
            {"text": "Build with Lego / Minecraft / Roblox", "points": ["MODANIM", "ARCHVIZ"]},
            {"text": "Challenge myself with video games and problem solving", "points": ["GAMES", "CODING"]},
            {"text": "Tinker on things, work on computers / robots", "points": ["CODING", "AIML"]}
        ]
    },
    {
        "question": "When I grow up I want to...",
        "options": [
            {"text": "Create stories and games", "points": ["GAMES"]},
            {"text": "Be an illustrator / graphic designer", "points": ["DMD"]},
            {"text": "Make / Build things that others can use", "points": ["MODANIM", "ARCHVIZ"]},
            {"text": "Work with computers and robots", "points": ["CODING", "AIML"]}
        ]
    },
    {
        "question": "If I had to describe my child they are strong in....",
        "options": [
            {"text": "Creative writing and drawing", "points": ["DMD", "MODANIM", "GAMES"]},
            {"text": "Maths, problem solving and logical", "points": ["CODING", "AIML", "GAMES"]},
            {"text": "Science, planning and tinkering", "points": ["ARCHVIZ", "CODING", "GAMES"]}
        ]
    },
    {
        "question": "What I want for my child is to...",
        "options": [
            {"text": "Pursue what they are passionate in", "points": ["DMD", "GAMES"]},
            {"text": "Learn a new skill with a qualification", "points": ["MODANIM", "ARCHVIZ"]},
            {"text": "Plan for their future and career", "points": ["CODING", "AIML"]}
        ]
    }
]

# ==========================================
# UTILITIES & MANAGERS
# ==========================================
def lerp(a, b, t):
    """Linear interpolation"""
    return a + (b - a) * t

def ease_out_expo(x):
    """Smooth easing function for animations"""
    return 1 if x == 1 else 1 - math.pow(2, -10 * x)

class ImageLoader:
    """Loads images with safe fallbacks."""
    def __init__(self):
        self.cache = {}
        
    def get_image(self, filename, size=None):
        if filename in self.cache:
            return self.cache[filename]
            
        path = os.path.join("assets", filename)
        if os.path.exists(path):
            try:
                img = pygame.image.load(path).convert_alpha()
                if size:
                    img = pygame.transform.smoothscale(img, size)
                self.cache[filename] = img
                return img
            except pygame.error:
                pass
        return None

class FontManager:
    """Handles font rendering and text wrapping."""
    def __init__(self):
        # Using a modern sans-serif fallback
        self.fonts = {}
        
    def get_font(self, size, bold=False):
        key = (size, bold)
        if key not in self.fonts:
            try:
                # Tries to use Segoe UI (Windows) or Arial as a clean modern font
                self.fonts[key] = pygame.font.SysFont("segoeui, arial, helvetica", size, bold=bold)
            except:
                self.fonts[key] = pygame.font.Font(None, size)
        return self.fonts[key]

    def render_wrapped_text(self, text, width, size, color, bold=False, center=True):
        font = self.get_font(size, bold)
        words = text.split(' ')
        lines = []
        current_line = []
        
        for word in words:
            test_line = ' '.join(current_line + [word])
            w, h = font.size(test_line)
            if w <= width:
                current_line.append(word)
            else:
                lines.append(' '.join(current_line))
                current_line = [word]
        lines.append(' '.join(current_line))
        
        line_height = font.size("Tg")[1]
        total_height = line_height * len(lines)
        surface = pygame.Surface((width, total_height), pygame.SRCALPHA)
        
        y_offset = 0
        for line in lines:
            rendered = font.render(line, True, color)
            x_offset = (width - rendered.get_width()) // 2 if center else 0
            surface.blit(rendered, (x_offset, y_offset))
            y_offset += line_height
            
        return surface

# ==========================================
# UI ELEMENTS
# ==========================================
class Button:
    def __init__(self, x, y, width, height, text, image_loader, font_manager, icon_file=None, on_click=None):
        self.rect = pygame.Rect(x, y, width, height)
        self.base_y = y 
        self.current_y = y + 800 
        self.text = text
        self.on_click = on_click
        self.image_loader = image_loader
        self.font_manager = font_manager
        
        # State
        self.hovered = False
        self.pressed = False
        self.scale = 1.0
        self.target_scale = 1.0
        self.anim_time = 0.0 
        
        self.img_normal = self.image_loader.get_image("btn_normal.png", (width, height))
        self.img_hover = self.image_loader.get_image("btn_hover.png", (width, height))
        
        # Icon Loading (40x40 size)
        self.icon_img = None
        if icon_file:
            self.icon_img = self.image_loader.get_image(icon_file, (40, 40))

        # Adjust text wrapping width if an icon is present
        text_width = width - 100 if icon_file else width - 40
        self.text_surf = self.font_manager.render_wrapped_text(text, text_width, 28, COLORS["text_light"], bold=True, center=False)

    def update(self, dt, events):
        # Entry animation
        if self.anim_time < 1.0:
            self.anim_time += dt * 2
            self.anim_time = min(self.anim_time, 1.0)
            eased = ease_out_expo(self.anim_time)
            self.current_y = lerp(self.base_y + 400, self.base_y, eased)
            self.rect.y = int(self.current_y)
        
        mouse_pos = pygame.mouse.get_pos()
        self.hovered = self.rect.collidepoint(mouse_pos)
        
        for event in events:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if self.hovered:
                    self.pressed = True
            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                if self.pressed and self.hovered and self.on_click:
                    self.on_click()
                self.pressed = False
                
        # Scale animation targets
        if self.pressed:
            self.target_scale = 0.95
        elif self.hovered:
            self.target_scale = 1.02
        else:
            self.target_scale = 1.0
            
        self.scale = lerp(self.scale, self.target_scale, dt * 15)

    def draw(self, surface):
        w = int(self.rect.width * self.scale)
        h = int(self.rect.height * self.scale)
        x = self.rect.centerx - w // 2
        y = self.rect.centery - h // 2
        draw_rect = pygame.Rect(x, y, w, h)
        
        if self.img_normal:
            img = self.img_hover if self.hovered else self.img_normal
            scaled_img = pygame.transform.smoothscale(img, (w, h))
            surface.blit(scaled_img, (x, y))
        else:
            color = COLORS["primary"] if self.hovered else COLORS["btn_bg"]
            if self.pressed:
                color = COLORS["secondary"]
            pygame.draw.rect(surface, color, draw_rect, border_radius=20)
            pygame.draw.rect(surface, COLORS["secondary"], draw_rect, width=2, border_radius=20)

        # Draw Icon and Text
        content_start_x = x + 30
        
        if self.icon_img:
            # Scale icon if button is scaling
            iw = int(40 * self.scale)
            ih = int(40 * self.scale)
            scaled_icon = pygame.transform.smoothscale(self.icon_img, (iw, ih))
            surface.blit(scaled_icon, (content_start_x, self.rect.centery - ih//2))
            content_start_x += iw + 20
        else:
            # Fallback Pygame Shape (Diamond)
            radius = int(15 * self.scale)
            cx, cy = content_start_x + radius, self.rect.centery
            pts = [(cx, cy - radius), (cx + radius, cy), (cx, cy + radius), (cx - radius, cy)]
            pygame.draw.polygon(surface, COLORS["text_light"], pts)
            content_start_x += (radius * 2) + 20

        # Draw Text
        tw = int(self.text_surf.get_width() * self.scale)
        th = int(self.text_surf.get_height() * self.scale)
        scaled_text = pygame.transform.smoothscale(self.text_surf, (tw, th))
        surface.blit(scaled_text, (content_start_x, self.rect.centery - th//2))

# ==========================================
# SCENES
# ==========================================
class Scene:
    def __init__(self, app):
        self.app = app
        self.dt = 0
    def update(self, dt, events): pass
    def draw(self, surface): pass

class QuestionScene(Scene):
    def __init__(self, app, q_data):
        super().__init__(app)
        self.q_data = q_data
        self.buttons = []
        
        # Setup Top 25% Question Text
        question_text = q_data["question"]
        self.q_surf = self.app.font_manager.render_wrapped_text(
            question_text, WIDTH - 100, 48, COLORS["text_light"], bold=True
        )
        
        # Setup Bottom 75% Options dynamically
        options = q_data["options"]
        num_opts = len(options)
        
        area_y = int(HEIGHT * 0.25)
        area_h = HEIGHT - area_y
        padding = 20
        total_padding = padding * (num_opts + 1)
        btn_height = (area_h - total_padding) // num_opts
        btn_width = int(WIDTH * 0.75)
        start_x = (WIDTH - btn_width) // 2
        
        for i, opt in enumerate(options):
            b_y = area_y + padding + i * (btn_height + padding)
            
            # Use default arg in lambda to avoid late-binding closure issues
            func = lambda points=opt["points"]: self.app.submit_answer(points)
            
            btn = Button(
                start_x, b_y, btn_width, btn_height, 
                opt["text"], self.app.image_loader, self.app.font_manager, 
                on_click=func
            )
            # Stagger entry animations
            btn.anim_time = -i * 0.15 
            self.buttons.append(btn)
            
    def update(self, dt, events):
        for btn in self.buttons:
            btn.update(dt, events)
            
    def draw(self, surface):
        # Draw Question Area background
        q_rect = pygame.Rect(0, 0, WIDTH, int(HEIGHT * 0.25))
        pygame.draw.rect(surface, COLORS["card"], q_rect)
        pygame.draw.line(surface, COLORS["primary"], (0, q_rect.bottom), (WIDTH, q_rect.bottom), 4)
        
        # Draw Question Text
        surface.blit(self.q_surf, ((WIDTH - self.q_surf.get_width()) // 2, (q_rect.height - self.q_surf.get_height()) // 2))
        
        # Draw Buttons
        for btn in self.buttons:
            btn.draw(surface)

class ReportScene(Scene):
    def __init__(self, app, top_courses):
        super().__init__(app)
        self.top_courses = top_courses
        self.anim_time = 0.0
        
        self.title_surf = self.app.font_manager.render_wrapped_text(
            "We will check out...", WIDTH, 56, COLORS["text_light"], bold=True
        )
        
        self.boxes = []
        box_w = 350
        box_h = 200
        padding = 40
        total_w = (box_w * 3) + (padding * 2)
        start_x = (WIDTH - total_w) // 2
        start_y = 350
        
        for i, course_key in enumerate(self.top_courses):
            bx = start_x + i * (box_w + padding)
            c_name = COURSES[course_key]
            c_color = COURSE_COLORS.get(course_key, COLORS["primary"])
            
            # Course Text
            text_surf = self.app.font_manager.render_wrapped_text(
                c_name, box_w - 100, 28, COLORS["text_dark"], bold=True, center=False
            )
            
            # Course Icon Loading
            icon_file = f"icon_{course_key.lower()}.png"
            icon_img = self.app.image_loader.get_image(icon_file, (60, 60))
            
            self.boxes.append({
                "rect": pygame.Rect(bx, start_y, box_w, box_h),
                "text": text_surf,
                "color": c_color,
                "icon": icon_img,
                "delay": i * 0.3, 
                "current_y": HEIGHT + 200
            })
            
    def update(self, dt, events):
        self.anim_time += dt
        for box in self.boxes:
            if self.anim_time > box["delay"]:
                progress = min((self.anim_time - box["delay"]) * 1.5, 1.0)
                eased = ease_out_expo(progress)
                box["current_y"] = lerp(HEIGHT + 200, box["rect"].y, eased)

    def draw(self, surface):
        surface.blit(self.title_surf, ((WIDTH - self.title_surf.get_width()) // 2, 100))
        
        for box in self.boxes:
            if self.anim_time > box["delay"]:
                draw_rect = pygame.Rect(box["rect"].x, int(box["current_y"]), box["rect"].width, box["rect"].height)
                
                # Draw unique colored box
                pygame.draw.rect(surface, box["color"], draw_rect, border_radius=25)
                pygame.draw.rect(surface, COLORS["text_light"], draw_rect, width=3, border_radius=25)
                
                # Draw Icon and Text
                content_x = draw_rect.x + 30
                if box["icon"]:
                    surface.blit(box["icon"], (content_x, draw_rect.centery - 30))
                    content_x += 80
                else:
                    # Fallback Pygame Shape (Circle)
                    pygame.draw.circle(surface, COLORS["text_dark"], (content_x + 30, draw_rect.centery), 30, width=3)
                    content_x += 80
                
                ty = draw_rect.centery - box["text"].get_height() // 2
                surface.blit(box["text"], (content_x, ty))

# ==========================================
# MAIN APPLICATION
# ==========================================
class QuizApp:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Free Assessment Quiz")
        pygame.display.set_icon(
            pygame.image.load("assets/logo.png")
        )
        self.clock = pygame.time.Clock()
        
        self.image_loader = ImageLoader()
        self.font_manager = FontManager()
        
        self.scores = {k: 0 for k in COURSES.keys()}
        self.current_q_index = 0
        
        self.scene = QuestionScene(self, QUESTIONS[self.current_q_index])
        
        # Transition variables
        self.transitioning = False
        self.trans_alpha = 0
        self.next_scene = None
        
    def submit_answer(self, points):
        if self.transitioning: return
        
        # Tally points
        for course in points:
            if course in self.scores:
                self.scores[course] += 1
                
        # Advance state
        self.current_q_index += 1
        if self.current_q_index < len(QUESTIONS):
            self.start_transition(QuestionScene(self, QUESTIONS[self.current_q_index]))
        else:
            # Calculate top 3
            sorted_courses = sorted(self.scores.items(), key=lambda x: x[1], reverse=True)
            top_3 = [c[0] for c in sorted_courses[:3]]
            self.start_transition(ReportScene(self, top_3))

    def start_transition(self, next_scene):
        self.transitioning = True
        self.next_scene = next_scene
        
    async def run(self):
        running = True
        while running:
            dt = self.clock.tick(FPS) / 1000.0
            events = pygame.event.get()
            
            for event in events:
                if event.type == pygame.QUIT:
                    running = False
            
            # --- UPDATE ---
            if not self.transitioning:
                self.scene.update(dt, events)
            else:
                self.trans_alpha += dt * 1500
                if self.trans_alpha >= 255:
                    self.trans_alpha = 255
                    self.scene = self.next_scene
                    self.transitioning = False
            
            # Fade-in state after scene swap
            if not self.transitioning and self.trans_alpha > 0:
                self.trans_alpha -= dt * 1500
                if self.trans_alpha < 0:
                    self.trans_alpha = 0
            
            # --- DRAW ---
            bg_img = self.image_loader.get_image("bg.png", (WIDTH, HEIGHT))
            if bg_img:
                self.screen.blit(bg_img, (0,0))
            else:
                self.screen.fill(COLORS["bg"])
                
            self.scene.draw(self.screen)
            
            # Draw Transition Overlay
            if self.trans_alpha > 0:
                overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
                overlay.fill((COLORS["bg"][0], COLORS["bg"][1], COLORS["bg"][2], int(self.trans_alpha)))
                self.screen.blit(overlay, (0, 0))
                
            pygame.display.flip()
            
            await asyncio.sleep(0)
            
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    app = QuizApp()
    asyncio.run(app.run())